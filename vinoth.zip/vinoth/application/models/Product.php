<?php
defined ('BASEPATH') OR exit('No direct script access allowed');

class Product extends CI_Model {





public function addproducts() //Get Value and Insert
{
  $pname = $this->input->post('pname');
  $pprice = $this->input->post('pprice');
  $pdesc = $this->input->post('pdesc');

  $pid = 'PROD'.uniqid();
  $pdate = date('d-m-Y');
  $ptime = date('h:i:sa');
  $pdatetime = date('d-m-Y h:i:sa');

$config['upload_path']          = 'assets/images/product';
$config['allowed_types']        = 'gif|jpg|png|jpeg';
//$config['max_size']             = 100;
//$config['max_width']            = 500;
//$config['max_height']           = 500;

$this->load->library('upload', $config);


if ( ! $this->upload->do_upload('pimg'))
{
$error = array('error' => $this->upload->display_errors());
//print_r($error);
$file_name = '';
}
else
{
//print_r("Success");
$upload_data = $this->upload->data();
$file_name = $upload_data['file_name'];
}


  $data = array(

    'prod_id'       =>$pid,
    'prod_name'    =>$pname,
    'prod_price'     =>$pprice,
    'prod_desc'     =>$pdesc,
    'prod_img'      =>$file_name,
    'regdate'     =>$pdate,
    'regtime'     =>$ptime,
    'regdatetime' =>$pdatetime,
    'status'   =>1
  );

  $this->db->insert('products',$data);

  if ($this->db->affected_rows() > 0) {
    redirect('welcome/index/1');
  }else {
    redirect('welcome/index/2');
  }

}

public function listallprods_view()
{
    $this->db->select ('*');
    $this->db->from('products')->order_by("id", "desc");
    $query = $this->db->get();
    return $query->result();
}



}