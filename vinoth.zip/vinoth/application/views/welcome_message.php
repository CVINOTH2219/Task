<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Shopping</title>
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/style.css" type="text/css">
  </head>
  <body>
    <div class="container">

      <!--Header-->

        <div class="col-md-12">
          <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" href="#">LOGO</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Link</a>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-expanded="false">
          Dropdown
        </a>
        <div class="dropdown-menu">
          <a class="dropdown-item" href="#">Action</a>
          <a class="dropdown-item" href="#">Another action</a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="#">Something else here</a>
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link disabled">Disabled</a>
      </li>
    </ul>
    <form class="form-inline my-2 my-lg-0">
      <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
      <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
    </form>
  </div>
</nav>
        </div>


      <!-- Header-->
      <!--Banner-->
      <div class="col-md-12">
      <div id="carouselExampleCaptions" class="carousel slide" data-ride="carousel">
        <ol class="carousel-indicators">
          <li data-target="#carouselExampleCaptions" data-slide-to="0" class="active"></li>
          <li data-target="#carouselExampleCaptions" data-slide-to="1"></li>
          <li data-target="#carouselExampleCaptions" data-slide-to="2"></li>
        </ol>
        <div class="carousel-inner">
          <div class="carousel-item active">
            <img src="https://www.thechennaimobiles.com/image/cache/catalog/lg_9kg%20front_01-600x600.jpg" class="d-block w-100" style="width:600; height:auto;" alt="...">
            <div class="carousel-caption d-none d-md-block">
              <h5>First slide label</h5>
              <p>Some representative placeholder content for the first slide.</p>
            </div>
          </div>
          <div class="carousel-item">
            <img src="https://www.thechennaimobiles.com/image/cache/catalog/lg_9kg%20front_05-600x600.jpg" class="d-block w-100" style="width:600; height:auto;" alt="...">
            <div class="carousel-caption d-none d-md-block">
              <h5>Second slide label</h5>
              <p>Some representative placeholder content for the second slide.</p>
            </div>
          </div>
          <div class="carousel-item">
            <img src="https://www.thechennaimobiles.com/image/cache/catalog/lg_9kg%20front_03-600x600.jpg" style="width:600; height:auto;"class="d-block w-100" alt="...">
            <div class="carousel-caption d-none d-md-block">
              <h5>Third slide label</h5>
              <p>Some representative placeholder content for the third slide.</p>
            </div>
          </div>
        </div>
        <button class="carousel-control-prev" type="button" data-target="#carouselExampleCaptions" data-slide="prev">
          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
          <span class="sr-only">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-target="#carouselExampleCaptions" data-slide="next">
          <span class="carousel-control-next-icon" aria-hidden="true"></span>
          <span class="sr-only">Next</span>
        </button>
      </div>
      </div>
      <!--Banner-->
      <!--Content in card-->
      <hr class="border-2">
      <div class="row">
      <?php

$listallprods_view = $this->product->listallprods_view(1);
foreach ($listallprods_view as $listallprods_viewArray) {
	$pid = $listallprods_viewArray->prod_id;

?>
      <div class="col-md-4 ">

        <div class="card-group ">

  <div class="card">
    <img src="<?php echo base_url(); ?>assets/images/product/<?php echo $listallprods_viewArray->prod_img; ?>" class="card-img-top"  alt="...">
    <div class="card-body">
      <h5 class="card-title"><?php echo $listallprods_viewArray->prod_name; ?></h5>
      <p class="card-text"><?php $prod_desc = $listallprods_viewArray->prod_desc; $prod_desc = substr($prod_desc, 0, 114); echo $prod_desc; ?></p>
    </div>
    <div class="card-footer">
      <h4 class="">Rs.<?php echo $listallprods_viewArray->prod_price; ?></h2>
    </div>
  </div>

  <!-- <div class="card">
    <img src="<?php //echo base_url();?>assets/images/img2.jpg" class="card-img-top" alt="...">
    <div class="card-body">
      <h5 class="card-title">Card title</h5>
      <p class="card-text">This card has supporting text below as a natural lead-in to additional content.</p>
    </div>
    <div class="card-footer">
      <small class="text-muted">Last updated 3 mins ago</small>
    </div>
  </div>
  <div class="card">
    <img src="<?php //echo base_url();?>assets/images/img3.jpg" class="card-img-top" alt="...">
    <div class="card-body">
      <h5 class="card-title">Card title</h5>
      <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This card has even longer content than the first to show that equal height action.</p>
    </div>
    <div class="card-footer">
      <small class="text-muted">Last updated 3 mins ago</small>
    </div>
  </div> -->
</div>

    </div>

	<?php } ?>
                                <?php if (empty($listallprods_view)): ?>
                                    <p class="card-text">Sorry! No Products Found....</p>
                                <?php endif; ?>
    <!--Content in card-->
    <!--Login form-->
    </div>

    <hr class="border-2">
    <div class="col-md-12 row">
      <div class="col-md-12">
        <form action="<?php echo site_url('welcome/addproducts'); ?>" method="post" enctype="multipart/form-data">
        <h2>Add Product</h2>
        <hr class="border-1">
        <div class="form-row">
          <div class="form-group col-md-6">
            <label for="inputEmail4">Product Name</label>
            <input type="text" name="pname" class="form-control" id="inputEmail4">
          </div>
          <div class="form-group col-md-6">
            <label for="inputPassword4">Product Price</label>
            <input type="text" name="pprice" class="form-control" id="inputPassword4">
          </div>
        </div>
        <div class="form-group">
          <label for="inputAddress">Product Description</label>
          <input type="textarea" name="pdesc" class="form-control" id="inputAddress" >
        </div>
		<div class="input-group mb-3">
  <div class="input-group-prepend">
    <span class="input-group-text" id="inputGroupFileAddon01">Choose Product Image</span>
  </div>
  <div class="custom-file">
    <input type="file" name="pimg" class="custom-file-input" id="inputGroupFile01" aria-describedby="inputGroupFileAddon01">
    <label class="custom-file-label" for="inputGroupFile01"></label>
  </div>
</div>

        <button type="submit" class="btn btn-primary">Submit</button>
      </form>
    </div>
    </div>
      </div>


  <script src="<?php echo base_url();?>assets/js/jquery.min.js"type="text/javascript"></script>
  <script src="<?php echo base_url();?>assets/js/popper.min.js"type="text/javascript"></script>
  <script src="<?php echo base_url();?>assets/js/bootstrap.min.js"type="text/javascript"></script>
  </body>
</html>
